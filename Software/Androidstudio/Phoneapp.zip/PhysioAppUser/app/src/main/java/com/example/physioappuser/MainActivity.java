package com.example.physioappuser;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.os.Vibrator;
import android.os.VibrationEffect;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import io.socket.client.IO;
import io.socket.client.Socket;
import io.socket.emitter.Emitter;
import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;
import okhttp3.OkHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    static double Highest = 300.0;
    static double Lowest = -300.0;
    static int repi = 0;
    String counter = "";
    static int device;
    Socket mSocket = null;
    String identity = "3";
    static double difficulty = 10;
    Boolean buzzerInd = true;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button buzz = (Button) findViewById(R.id.buzzer);
        buzz.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v){
                buzzerInd = !buzzerInd;
                Log.d("buzzer", buzzerInd.toString());
                if (buzzerInd) {
                    buzz.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#4CAF50")));
                    buzz.setText("ON");
                } else {
                    buzz.setBackgroundTintList(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                    buzz.setText("OFF");
                }
            }

        });

        final Vibrator vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);


        TextView Peak = (TextView) findViewById(R.id.PeakAngle);
        TextView Trough = (TextView) findViewById(R.id.LowestAngle);
        TextView Current = (TextView) findViewById(R.id.CurrentAngle);
        TextView rep = (TextView) findViewById(R.id.rep);
        EditText deviceNum = (EditText) findViewById(R.id.DeviceNum);

        try {
            IO.Options options = new IO.Options();
            options.callFactory = new OkHttpClient.Builder()
                                    .connectTimeout(0, TimeUnit.MILLISECONDS)
                                    .readTimeout(0, TimeUnit.MILLISECONDS)
                                    .writeTimeout(0, TimeUnit.MILLISECONDS)
                                    .build();

            mSocket = IO.socket("http://10.3.141.1:5000", options);
            Log.d("Socket Connection", "Connected");
        } catch (URISyntaxException e) {
            Log.d("Error connecting", e.toString());
        }
        new Emitter.Listener() {
            public void call(Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    public void run() {
                        Log.d("Connect", "connected");
                    }
                });
            }
        };
        mSocket.on("log", new Emitter.Listener() {
            public void call(final Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @RequiresApi(api = Build.VERSION_CODES.O)
                    public void run() {
                        JSONObject data = (JSONObject) args[0];
                        try {

                            if ( !deviceNum.getText().toString().isEmpty()) {
                                device = Integer.parseInt(deviceNum.getText().toString());
                                Log.d("Hello", String.valueOf(device));
                                if (device==1){
                                    identity="Sensor1";
                                } else if(device==2 ){
                                    identity="Sensor2";
                                } else if(device==3 ){
                                    identity="Sensor3";
                                }
                                Log.d("Hello", identity);
                            }

                            rep.setText(Integer.toString(repi));
                            String current = data.getString(identity);
                            Current.setText(current);
                            float angle = Float.parseFloat(current);
                            if (angle != -1.0) {
                                if (angle < Highest) {
                                    Peak.setText(current);
                                    Highest = Double.parseDouble(current);
                                } else if (angle > Lowest) {
                                    Trough.setText(current);
                                    Lowest = Double.parseDouble(current);
                                }
                            }
                            double thresholdH = Highest + difficulty;
                            double thresholdL = Lowest - difficulty;
                            if (Lowest-Highest>10) {

                                if (angle < thresholdH) {
                                    if (counter == "") {
                                        counter = "A";
                                        Current.setTextColor(ColorStateList.valueOf(Color.parseColor("#FF0000")));
                                        final VibrationEffect vibrationEffect1;
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && buzzerInd) {
                                            vibrationEffect1 = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE);
                                            vibrator.cancel();
                                            vibrator.vibrate(vibrationEffect1);
                                        }
                                    }
                                }
                                if (angle > thresholdL) {
                                    if (counter == "A") {
                                        repi += 1;
                                        counter = "";
                                        Current.setTextColor(ColorStateList.valueOf(Color.parseColor("#0000FF")));
                                        final VibrationEffect vibrationEffect1;
                                        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O && buzzerInd) {
                                            vibrationEffect1 = VibrationEffect.createOneShot(500, VibrationEffect.DEFAULT_AMPLITUDE);
                                            vibrator.cancel();
                                            vibrator.vibrate(vibrationEffect1);
                                        }

                                    }
                                }
                            }


                        } catch (JSONException e) {
                            Log.d("Json Error", e.toString());
                        }

                    }
                });
            }
        });
        mSocket.connect();
    }

    private void sendMessage(String event, String message) {
        if (!mSocket.connected()) return;

        // perform the sending message attempt.
        mSocket.emit(event, message);
    }
}