package com.example.anative;

import androidx.appcompat.app.AppCompatActivity;
import io.socket.client.IO;
import io.socket.client.Socket;
import android.os.Bundle;
import android.util.Log;
import android.widget.EditText;

import org.json.JSONException;
import org.json.JSONObject;

import java.net.URISyntaxException;
import java.util.Iterator;
import java.util.concurrent.TimeUnit;

import io.socket.emitter.Emitter;
import okhttp3.OkHttpClient;

public class MainActivity extends AppCompatActivity {
    static double Highest;
    static double Lowest;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText PeakA = findViewById(R.id.PeakAngle);
        final EditText LowestA = findViewById(R.id.LowestAngle);
        final EditText CurrentA = findViewById(R.id.CurrentAngle);
        Socket mSocket = null;


        {
            try {
                IO.Options options = new IO.Options();
                OkHttpClient.Builder clientBuilder = new OkHttpClient.Builder()
                        .connectTimeout(0, TimeUnit.MILLISECONDS)
                        .readTimeout(0, TimeUnit.MILLISECONDS)
                        .writeTimeout(0, TimeUnit.MILLISECONDS);
                options.callFactory = clientBuilder.build();
                mSocket = IO.socket("http://10.3.141.1:5000", options);
                Log.d("Socket Connection", "Connected");
            } catch (URISyntaxException e) {
                Log.d("Error connecting", e.toString());
            }
        }

        Emitter.Listener onConnect = new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Log.d("Connect", "connected");
                    }
                });
            }
        };


         Emitter.Listener onLog = new Emitter.Listener() {
            @Override
            public void call(final Object... args) {
                MainActivity.this.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        JSONObject data = (JSONObject) args[0];


                        try {
                            String angle1 = data.getString("Sensor1");
                            Double angle1C = data.getDouble("Sensor1");
                            CurrentA.setText(angle1);




                            Log.d("hello", angle1);
                        } catch (JSONException e) {
                            Log.d("Json Error", e.toString());
                        }
                    }



                });
            }
        };
        mSocket.on("log", onLog);
        mSocket.connect();
    }

}